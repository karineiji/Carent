package com.tarek.carsharing.Model;

public enum CarStatus {
    ON, OFF ,BROKEN
}
