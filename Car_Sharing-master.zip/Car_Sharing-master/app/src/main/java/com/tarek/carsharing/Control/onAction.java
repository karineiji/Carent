package com.tarek.carsharing.Control;

public interface onAction {
    void onStart();
    void onFinish(Object object);
}
