package com.tarek.carsharing.Model;

public enum CarTrip {
    START,END
}
