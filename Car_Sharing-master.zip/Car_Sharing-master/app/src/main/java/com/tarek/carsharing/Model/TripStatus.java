package com.tarek.carsharing.Model;

public enum TripStatus {
    FINISHED, INPROGRESS
}
