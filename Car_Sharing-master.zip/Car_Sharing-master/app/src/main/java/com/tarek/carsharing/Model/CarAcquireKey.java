package com.tarek.carsharing.Model;

public enum CarAcquireKey {
    LOCK,  UNLOCK
}
